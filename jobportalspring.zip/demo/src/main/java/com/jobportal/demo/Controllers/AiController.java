package com.jobportal.demo.Controllers;

import com.jobportal.demo.response.ApiResponse;
import com.jobportal.demo.service.GeminiService;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

@RestController
@RequestMapping("/api/ai")
@CrossOrigin(origins = "http://localhost:3000")
public class AiController {

    @Autowired
    private GeminiService geminiService;

    @PostMapping("/upload-resume")
    public ResponseEntity<String> uploadResume(@RequestParam("file") MultipartFile file) throws IOException {
        String content;

        if (file.getContentType().equals("application/pdf")) {
            try (PDDocument document = PDDocument.load(file.getInputStream())) {
                PDFTextStripper stripper = new PDFTextStripper();
                content = stripper.getText(document);
            }
        } else {
            content = new String(file.getBytes()); // for .txt files
        }

        return ResponseEntity.ok(content);
    }

    @PostMapping("/ask")
    public ResponseEntity<ApiResponse<String>> askGemini(@RequestBody PromptRequest request) {
        try {
            String response = geminiService.askGemini(request.getPrompt());
            return ResponseEntity.ok(new ApiResponse<>(true, response, null));
        } catch (Exception e) {
            return ResponseEntity
                    .status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new ApiResponse<>(false, null, "AI failed to respond: " + e.getMessage()));
        }
    }

    // Inner class for prompt request body
    public static class PromptRequest {
        private String prompt;
        public String getPrompt() { return prompt; }
        public void setPrompt(String prompt) { this.prompt = prompt; }
    }
}
