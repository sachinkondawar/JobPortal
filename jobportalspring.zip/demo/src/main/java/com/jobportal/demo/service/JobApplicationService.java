package com.jobportal.demo.service;


import com.jobportal.demo.Model.Job;
import com.jobportal.demo.Model.JobApplication;
import com.jobportal.demo.Model.User;
import com.jobportal.demo.Repository.JobApplicationRepository;
import com.jobportal.demo.Repository.JobRepository;
import com.jobportal.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Service
public class JobApplicationService {

    @Autowired
    private JobApplicationRepository applicationRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    public JobApplication applyToJob(Long jobId, Long applicantId) {
        Job job = jobRepository.findById(jobId)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        User applicant = userRepository.findById(applicantId)
                .filter(u -> u.getRole() == User.Role.JOB_SEEKER)
                .orElseThrow(() -> new RuntimeException("Applicant not valid"));

        JobApplication application = new JobApplication();
        application.setJob(job);
        application.setApplicant(applicant);
        application.setApplyDate(LocalDate.now());

        return applicationRepository.save(application);
    }

    public List<JobApplication> getApplicationsForJob(Long jobId) {
        return applicationRepository.findByJobId(jobId);
    }

    public List<JobApplication> getApplicationsByUser(Long userId) {
        return applicationRepository.findByApplicantId(userId);
    }
}
