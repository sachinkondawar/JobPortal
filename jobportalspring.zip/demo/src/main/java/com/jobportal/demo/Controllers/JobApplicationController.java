package com.jobportal.demo.Controllers;

import com.jobportal.demo.Model.Job;
import com.jobportal.demo.Model.JobApplication;
import com.jobportal.demo.Model.User;
import com.jobportal.demo.Repository.JobApplicationRepository;
import com.jobportal.demo.Repository.JobRepository;
import com.jobportal.demo.Repository.UserRepository;
import com.jobportal.demo.dto.UserApplicationDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/applications")
public class JobApplicationController {

    @Autowired
    private JobApplicationRepository applicationRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/apply/{jobId}/{applicantId}")
    public ResponseEntity<JobApplication> apply(
            @PathVariable Long jobId,
            @PathVariable Long applicantId
    ) {
        Optional<Job> job = jobRepository.findById(jobId);
        Optional<User> user = userRepository.findById(applicantId);

        if (job.isEmpty() || user.isEmpty() || user.get().getRole() != User.Role.JOB_SEEKER) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }

        JobApplication application = new JobApplication();
        application.setJob(job.get());
        application.setApplicant(user.get());
        application.setApplyDate(LocalDate.now());

        return ResponseEntity.ok(applicationRepository.save(application));
    }

    @GetMapping("/job/{jobId}")
    public ResponseEntity<List<JobApplication>> getApplicationsForJob(@PathVariable Long jobId) {
        return ResponseEntity.ok(applicationRepository.findByJobId(jobId));
    }

    @GetMapping("/user/{userId}")
    public List<UserApplicationDTO> getApplicationsByUser(@PathVariable Long userId) {
        List<JobApplication> apps = applicationRepository.findByApplicantId(userId);
        return apps.stream().map(app -> {
            UserApplicationDTO dto = new UserApplicationDTO();
            dto.setId(app.getId());
            dto.setAppliedDate(app.getApplyDate());
            dto.setJobTitle(app.getJob().getTitle());
            dto.setEmployerName(app.getJob().getEmployer().getName());
            return dto;
        }).toList();
    }


}
