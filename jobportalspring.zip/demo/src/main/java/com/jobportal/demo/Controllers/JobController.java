package com.jobportal.demo.Controllers;

import com.jobportal.demo.Model.Job;
import com.jobportal.demo.Model.User;
import com.jobportal.demo.Repository.JobRepository;
import com.jobportal.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/jobs")
public class JobController {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    @PostMapping("/post/{employerId}")
    public ResponseEntity<Job> postJob(@PathVariable Long employerId, @RequestBody Job job) {
        Optional<User> employer = userRepository.findById(employerId);
        if (employer.isEmpty() || !employer.get().getRole().equals(User.Role.EMPLOYER)) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).build();
        }
        job.setEmployer(employer.get());
        job.setPostedDate(LocalDate.now());
        return ResponseEntity.ok(jobRepository.save(job));
    }

    @GetMapping
    public ResponseEntity<List<Job>> getAllJobs() {
        return ResponseEntity.ok(jobRepository.findAll());
    }

    @GetMapping("/search")
    public ResponseEntity<List<Job>> searchJobs(@RequestParam String keyword) {
        return ResponseEntity.ok(jobRepository.findByTitleContainingIgnoreCase(keyword));
    }
}
