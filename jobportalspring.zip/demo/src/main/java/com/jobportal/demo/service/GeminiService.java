package com.jobportal.demo.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.net.http.*;

@Service
public class GeminiService {

    @Value("${gemini.api.key}")
    private String apiKey;

    public String askGemini(String prompt) {
        try {
            ObjectMapper mapper = new ObjectMapper();

            // Safely escape and log the prompt
            String safePrompt = mapper.writeValueAsString(prompt);
            System.out.println("Sending prompt to Gemini: " + safePrompt);

            // Build the JSON request payload
            String jsonRequest = """
                {
                  "contents": [
                    {
                      "parts": [
                        {
                          "text": %s
                        }
                      ]
                    }
                  ]
                }
            """.formatted(safePrompt);

            // Build and send the HTTP request
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" + apiKey))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonRequest))
                    .build();

            HttpClient client = HttpClient.newHttpClient();
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Log the raw response for debugging
            System.out.println("Gemini raw response: " + response.body());

            // Parse and extract response
            JsonNode root = mapper.readTree(response.body());
            JsonNode candidates = root.path("candidates");

            if (!candidates.isArray() || candidates.isEmpty()) {
                return "❌ No response from Gemini AI (candidates missing)";
            }

            JsonNode parts = candidates.get(0).path("content").path("parts");
            if (!parts.isArray() || parts.isEmpty()) {
                return "❌ No parts found in AI response";
            }

            String result = parts.get(0).path("text").asText(null);
            return result != null ? result : "❌ Gemini response text is missing";

        } catch (Exception e) {
            return "❌ Error calling Gemini API: " + e.getMessage();
        }
    }
}
