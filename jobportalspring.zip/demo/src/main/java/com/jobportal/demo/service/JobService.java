package com.jobportal.demo.service;

import com.jobportal.demo.Model.Job;
import com.jobportal.demo.Model.User;
import com.jobportal.demo.Repository.JobRepository;
import com.jobportal.demo.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class JobService {

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private UserRepository userRepository;

    public Job postJob(Long employerId, Job job) {
        User employer = userRepository.findById(employerId)
                .filter(u -> u.getRole() == User.Role.EMPLOYER)
                .orElseThrow(() -> new RuntimeException("Employer not found"));

        job.setEmployer(employer);
        job.setPostedDate(LocalDate.now());
        return jobRepository.save(job);
    }

    public List<Job> getAllJobs() {
        return jobRepository.findAll();
    }

    public List<Job> searchJobs(String keyword) {
        return jobRepository.findByTitleContainingIgnoreCase(keyword);
    }
}
